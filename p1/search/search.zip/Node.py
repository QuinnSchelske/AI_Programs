class Node:
	def __init__(self, state, parent, action,cost):
		self.state = state
		self.action = action
		self.parent = parent
		self.cost = cost



